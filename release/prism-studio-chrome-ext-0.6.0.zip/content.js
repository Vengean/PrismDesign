var e=`data-prism-result`,t=`__prism_inspect`;function n(n){try{n.dispatchEvent(new CustomEvent(t,{bubbles:!1}));let r=n.getAttribute(e);if(n.removeAttribute(e),!r||r===`null`)return null;let i=JSON.parse(r);return i.error?(console.warn(`[Prism Studio] page-bridge error:`,i.error),null):i}catch{return null}}var r=null,i=null;function a(e){return r===e?i:(i=n(e),r=e,i)}function o(e){let t=a(e);return t?t.component?t.component:t.vue?{name:t.vue.name,props:t.vue.props,sourceFile:t.vue.sourceFile}:null:null}function s(e){let t=a(e);if(!t)return[];if(t.chain.length>0)return t.chain;let r=[],i=e;for(;i&&i!==document.body;){let e=n(i);if(e?.vue){let t=e.vue.name;(r.length===0||r[r.length-1].name!==t)&&r.push({name:t,sourceFile:e.vue.sourceFile})}i=i.parentElement}return r.reverse(),r}function c(e){let t=window.getComputedStyle(e),n=`color.backgroundColor.fontSize.fontWeight.fontFamily.lineHeight.letterSpacing.textAlign.width.height.maxWidth.maxHeight.minWidth.minHeight.padding.paddingTop.paddingRight.paddingBottom.paddingLeft.margin.marginTop.marginRight.marginBottom.marginLeft.borderRadius.borderColor.borderWidth.display.flexDirection.justifyContent.alignItems.gap.opacity.boxShadow`.split(`.`),r={};for(let e of n)r[e]=t.getPropertyValue(e.replace(/([A-Z])/g,`-$1`).toLowerCase());return r}function ee(e){let t=[],n=e;for(;n&&n!==document.body;){let e=n.tagName.toLowerCase();if(n.id&&!n.id.startsWith(`prism-studio-`))e+=`#${n.id}`;else{if(n.className&&typeof n.className==`string`){let t=n.className.trim().split(/\s+/).filter(e=>!e.startsWith(`prism-studio-`)&&!e.startsWith(`css-`)).slice(0,2).join(`.`);t&&(e+=`.${t}`)}let t=n.parentElement;if(t){let r=Array.from(t.children).indexOf(n);e+=`[${r}]`}}t.unshift(e),n=n.parentElement}return t.join(` > `)}function te(e,t=0,n=4){let r=`  `.repeat(t),i=e.tagName.toLowerCase(),a=``;e.id&&(a+=` id="${e.id}"`);let o=typeof e.className==`string`?e.className.trim():``;o&&(a+=` class="${o.split(` `).slice(0,3).join(` `)}${o.split(` `).length>3?` ...`:``}"`);let s=e.children;if(s.length===0||t>=n){let t=(e.innerText||``).trim().replace(/\s+/g,` `);if(!t)return`${r}<${i}${a} />`;let n=t.length>30?t.slice(0,30)+`...`:t;return`${r}<${i}${a}>${n}</${i}>`}let c=[];c.push(`${r}<${i}${a}>`);for(let t of e.childNodes){if(t===s[0])break;if(t.nodeType===Node.TEXT_NODE){let e=(t.textContent||``).trim();if(e){let t=e.length>30?e.slice(0,30)+`...`:e;c.push(`${r}  ${t}`)}}}return c.push(te(s[0],t+1,n)),s.length>1&&c.push(`${r}  ...`),c.push(`${r}</${i}>`),c.join(`
`)}var ne=new Set([`span`,`p`,`h1`,`h2`,`h3`,`h4`,`h5`,`h6`,`a`,`label`,`strong`,`em`,`b`,`i`,`li`,`td`,`th`,`dt`,`dd`,`figcaption`]);function l(e){r=null,i=null;let t=o(e),n=s(e),a=e.getBoundingClientRect(),l=e.tagName.toLowerCase(),u=window.getComputedStyle(e).display;return{pagePath:window.location.pathname,domPath:ee(e),tagName:l,id:e.id||``,textContent:te(e),className:typeof e.className==`string`?e.className:``,role:e.getAttribute(`role`)||``,ariaLabel:e.getAttribute(`aria-label`)||``,component:t,componentChain:n.map(e=>e.name).join(` > `),componentChainDetail:n,styles:c(e),rect:{top:a.top+window.scrollY,left:a.left+window.scrollX,width:a.width,height:a.height},isTextElement:ne.has(l)||e.children.length===0,isFlexContainer:u===`flex`||u===`inline-flex`}}var u=null,d=null,re=null,f=null,p=null,m=null,ie=`2px solid #6366f1`,ae=`-2px`,oe=`prism-studio-selected`,h=null;function se(){h||(h=document.createElement(`style`),h.id=`prism-studio-overlay-style`,h.textContent=`
    .${oe} {
      outline: ${ie} !important;
      outline-offset: ${ae} !important;
    }
  `,document.head.appendChild(h))}function ce(e,t){let n=document.createElement(`div`);return n.id=e,Object.assign(n.style,{position:`absolute`,pointerEvents:`none`,zIndex:`2147483646`,border:`2px solid ${t}`,borderRadius:`3px`,transition:`all 0.1s ease`,display:`none`}),document.body.appendChild(n),n}function le(){let e=document.createElement(`div`);return e.id=`prism-studio-label`,Object.assign(e.style,{position:`absolute`,pointerEvents:`none`,zIndex:`2147483647`,background:`#6366f1`,color:`#fff`,fontSize:`11px`,fontFamily:`monospace`,padding:`2px 6px`,borderRadius:`3px`,whiteSpace:`nowrap`,display:`none`}),document.body.appendChild(e),e}function ue(){if(!u||!f)return;let e=f.getBoundingClientRect();Object.assign(u.style,{top:`${e.top+window.scrollY}px`,left:`${e.left+window.scrollX}px`,width:`${e.width}px`,height:`${e.height}px`}),d&&d.style.display!==`none`&&Object.assign(d.style,{top:`${e.top+window.scrollY-20}px`,left:`${e.left+window.scrollX}px`})}function de(e){fe(),f=e,p=new ResizeObserver(()=>ue()),p.observe(e);let t=()=>{f&&(ue(),m=requestAnimationFrame(t))};m=requestAnimationFrame(t)}function fe(){p?.disconnect(),p=null,m!==null&&(cancelAnimationFrame(m),m=null),f=null}function pe(){document.getElementById(`prism-studio-hover`)?.remove(),document.getElementById(`prism-studio-label`)?.remove(),h?.remove(),h=null,se(),u=ce(`prism-studio-hover`,`rgba(99, 102, 241, 0.6)`),d=le()}function me(e,t){if(!u||!d)return;let n=e.getBoundingClientRect();Object.assign(u.style,{display:`block`,top:`${n.top+window.scrollY}px`,left:`${n.left+window.scrollX}px`,width:`${n.width}px`,height:`${n.height}px`,backgroundColor:`rgba(99, 102, 241, 0.08)`});let r=t||e.tagName.toLowerCase();d.textContent=r,Object.assign(d.style,{display:`block`,top:`${n.top+window.scrollY-20}px`,left:`${n.left+window.scrollX}px`}),de(e)}function g(){u&&(u.style.display=`none`),d&&(d.style.display=`none`),fe()}function _(e){v(),se(),re=e,e.classList.add(oe)}function v(){re&&=(re.classList.remove(oe),null)}function he(){v(),fe(),[u,d,h].forEach(e=>e?.remove()),u=null,d=null,h=null}var y=new Map,b=new Map,ge=new Map,x=null,_e=[],ve=null,S=null,ye=null;function be(e){ye=e}function xe(){S||(S=document.createElement(`style`),S.id=`prism-studio-editor-style`,S.textContent=`
    .prism-studio-text-editing {
      outline: 2px dashed #f59e0b !important;
      outline-offset: 2px;
      cursor: text !important;
    }
    .prism-studio-drag-mode,
    .prism-studio-drag-mode * {
      cursor: grab !important;
    }
    .prism-studio-drag-over-top {
      border-top: 3px solid #6366f1 !important;
    }
    .prism-studio-drag-over-left {
      border-left: 3px solid #6366f1 !important;
    }
    .prism-studio-dragging {
      opacity: 0.4 !important;
    }
  `,document.head.appendChild(S))}function Se(){S?.remove(),S=null,ve=null,b.forEach((e,t)=>{t.classList.remove(`prism-studio-text-editing`)}),ge.forEach((e,t)=>{t.contentEditable=`false`})}function Ce(e){if(ve=e,!b.has(e)){let t=window.getComputedStyle(e);b.set(e,{color:t.color,backgroundColor:t.backgroundColor,fontSize:t.fontSize,fontWeight:t.fontWeight,lineHeight:t.lineHeight,padding:t.padding,margin:t.margin,borderRadius:t.borderRadius,gap:t.gap})}}var we=[`prism-studio-drag-over-top`,`prism-studio-drag-over-left`];function Te(e){e.classList.remove(...we)}function Ee(e){let t=window.getComputedStyle(e),n=t.display;if(n===`flex`||n===`inline-flex`){let e=t.flexDirection;return e===`row`||e===`row-reverse`}if(n===`grid`||n===`inline-grid`){let e=t.gridTemplateColumns;return e!==`none`&&e.split(/\s+/).length>1}return!1}function De(e,t){e.preventDefault();let n=t.parentElement;if(!n)return;let r=Array.from(n.children).filter(e=>!e.id?.startsWith(`prism-studio-`)),i=r.indexOf(t);t.classList.add(`prism-studio-dragging`);let a=Ee(n)?`prism-studio-drag-over-left`:`prism-studio-drag-over-top`;x={element:t,startY:e.clientY,siblings:r};let o=e=>{if(!x)return;let n=document.elementFromPoint(e.clientX,e.clientY);if(!n||n===t)return;let r=x.siblings.find(e=>e===n||e.contains(n));r&&r!==t&&(x.siblings.forEach(e=>Te(e)),r.classList.add(a))},s=e=>{if(document.removeEventListener(`mousemove`,o),document.removeEventListener(`mouseup`,s),!x)return;t.classList.remove(`prism-studio-dragging`),x.siblings.forEach(e=>Te(e));let r=document.elementFromPoint(e.clientX,e.clientY),a=x.siblings.find(e=>e===r||e.contains(r));if(a&&a!==t){let e=x.siblings.indexOf(a);e>i?n.insertBefore(t,a.nextSibling):n.insertBefore(t,a),_e.push({element:Oe(t),from:i,to:e});try{ye?.(t,i,e)}catch(e){console.error(`[Prism Studio] drag callback error:`,e)}}x=null};document.addEventListener(`mousemove`,o),document.addEventListener(`mouseup`,s)}function Oe(e){let t=[],n=e;for(;n&&n!==document.body;){let e=n.tagName.toLowerCase();if(n.id&&!n.id.startsWith(`prism-studio-`))e+=`#${n.id}`;else{if(n.className&&typeof n.className==`string`){let t=n.className.split(/\s+/).filter(e=>!e.startsWith(`prism-studio-`)).slice(0,2).join(`.`);t&&(e+=`.${t}`)}let t=n.parentElement;if(t){let r=Array.from(t.children).indexOf(n);e+=`[${r}]`}}t.unshift(e),n=n.parentElement}return t.join(` > `)}function ke(e,t,n,r){let i=Oe(e),a=`${i}::${t}`,o=y.get(a);y.set(a,{selector:i,property:t,oldValue:o?o.oldValue:n,newValue:r,textContent:(e.textContent||``).trim().slice(0,60)})}function Ae(){return ve}function je(){return Array.from(y.values())}function Me(){return[..._e]}function Ne(){y.clear(),b=new Map,ge=new Map,_e=[]}var Pe=new Set([`script`,`style`,`link`,`meta`,`noscript`,`svg`]);function Fe(e){let t=e;for(;t;){if(t.id?.startsWith(`prism-studio-`))return!0;t=t.parentElement}return!1}function Ie(e){let t=Object.keys(e).find(e=>e.startsWith(`__reactFiber$`)||e.startsWith(`__reactInternalInstance$`));if(t){let n=e[t];for(;n;){if(typeof n.type==`function`&&!n._debugSource?.fileName?.includes(`node_modules`))return n.type.displayName||n.type.name||null;n=n.return}}let n=e.__vueParentComponent;if(n)return n.type.__name||n.type.name||null;let r=e.__vue__;return r&&r.$options.name||null}function Le(e){let t=[],n=e;for(;n&&n!==document.body;){let e=n.tagName.toLowerCase();if(n.id&&!n.id.startsWith(`prism-studio-`))e+=`#${n.id}`;else{if(n.className&&typeof n.className==`string`){let t=n.className.trim().split(/\s+/).filter(e=>!e.startsWith(`prism-studio-`)&&!e.startsWith(`css-`)).slice(0,2).join(`.`);t&&(e+=`.${t}`)}let t=n.parentElement;if(t){let r=Array.from(t.children).indexOf(n);e+=`[${r}]`}}t.unshift(e),n=n.parentElement}return t.join(` > `)}var Re=0;function ze(e,t=20,n=0){if(n>t)return[];let r=[],i=Array.from(e.children);for(let e of i){if(Pe.has(e.tagName.toLowerCase())||Fe(e))continue;let i=Array.from(e.children).filter(e=>!Pe.has(e.tagName.toLowerCase())&&!Fe(e)).length>0,a=i?ze(e,t,n+1):[],o=e.className&&typeof e.className==`string`?e.className.trim().split(/\s+/).filter(e=>!e.startsWith(`css-`)).slice(0,2).join(` `):``;r.push({id:`pdn-${++Re}`,tagName:e.tagName.toLowerCase(),className:o,componentName:Ie(e),domPath:Le(e),hasChildren:i,children:a})}return r}function Be(){Re=0}var C=!1,w={},T={},E={};function Ve(e){if(!C)return;let t=document.activeElement;if(t&&(t.tagName===`INPUT`||t.tagName===`TEXTAREA`||t.tagName===`SELECT`||t.contentEditable===`true`))return;let n=e.key.toLowerCase(),r=E[n];if(r&&!e.ctrlKey&&!e.metaKey&&!e.altKey){e.preventDefault(),r();return}if((e.ctrlKey||e.metaKey)&&e.shiftKey){let t=T[n];if(t){e.preventDefault(),t();return}}if(!(e.ctrlKey||e.metaKey))return;let i=w[n];i&&(e.preventDefault(),i())}function He(e){w=e.ctrl||{},T=e.ctrlShift||{},E=e.plain||{},C=!0,document.addEventListener(`keydown`,Ve,!0)}function Ue(){C=!1,document.removeEventListener(`keydown`,Ve,!0),w={},T={},E={}}var We={"toolbar.select":`选择元素`,"toolbar.drag":`拖拽排列`,"toolbar.comment":`评论`,"comment.placeholder":`输入评论...`,"comment.cancel":`取消`,"comment.confirm":`确认`},Ge={"toolbar.select":`Select Element`,"toolbar.drag":`Drag to Reorder`,"toolbar.comment":`Comment`,"comment.placeholder":`Enter comment...`,"comment.cancel":`Cancel`,"comment.confirm":`Confirm`},Ke=`en`;try{Ke=(typeof chrome<`u`&&chrome.i18n?.getUILanguage?.()||navigator.language||`en`).startsWith(`zh`)?`zh`:`en`}catch{}var qe={zh:We,en:Ge};function D(e){return qe[Ke]?.[e]||qe.en[e]||e}var O=null,k=null,A=null,j=!1,Je=null,M=typeof navigator<`u`&&/Mac/i.test(navigator.platform)?`⌘⇧`:`Ctrl+Shift+`;function Ye(e){O||(Je=e,document.getElementById(`prism-studio-toolbar`)?.remove(),document.getElementById(`prism-studio-toolbar-style`)?.remove(),k=document.createElement(`style`),k.id=`prism-studio-toolbar-style`,k.textContent=`
    #prism-studio-toolbar {
      position: fixed;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 2147483647;
      background: #fff;
      border: 1px solid #e5e7eb;
      border-radius: 14px;
      padding: 6px 8px;
      display: flex;
      align-items: center;
      gap: 2px;
      box-shadow: 0 4px 24px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.04);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      user-select: none;
    }
    #prism-studio-toolbar button {
      position: relative;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      height: 34px;
      width: 34px;
      border: none;
      border-radius: 8px;
      background: transparent;
      color: #6b7280;
      cursor: pointer;
      transition: all 0.15s;
      padding: 0;
    }
    #prism-studio-toolbar button:focus { outline: none; }
    #prism-studio-toolbar button:hover { background: #f3f4f6; color: #374151; }
    #prism-studio-toolbar button.pd-active { background: #ede9fe; color: #6366f1; }
    #prism-studio-toolbar button svg { width: 18px; height: 18px; flex-shrink: 0; }
    #prism-studio-toolbar.pd-disabled {
      pointer-events: none;
      opacity: 0;
    }
    /* Tooltip */
    #prism-studio-toolbar button .pd-tooltip {
      position: absolute;
      bottom: calc(100% + 8px);
      left: 50%;
      transform: translateX(-50%);
      background: #1f2937;
      color: #fff;
      font-size: 11px;
      line-height: 1.3;
      padding: 4px 8px;
      border-radius: 6px;
      white-space: nowrap;
      pointer-events: none;
      opacity: 0;
      transition: opacity 0.15s;
    }
    #prism-studio-toolbar button .pd-tooltip .pd-shortcut {
      color: #9ca3af;
      margin-left: 4px;
      font-size: 10px;
    }
    @media (hover: hover) {
      #prism-studio-toolbar button:hover .pd-tooltip {
        opacity: 1;
      }
    }
    #prism-studio-toolbar.pd-disabled button:hover .pd-tooltip,
    #prism-studio-toolbar button.pd-active .pd-tooltip {
      opacity: 0;
    }
  `,document.head.appendChild(k),O=document.createElement(`div`),O.id=`prism-studio-toolbar`,O.innerHTML=`
    <button id="pd-tb-select">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/><path d="M13 13l6 6"/></svg>
      <span class="pd-tooltip">${D(`toolbar.select`)}<span class="pd-shortcut">${M}E</span></span>
    </button>
    <button id="pd-tb-drag">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2"/><path d="M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2"/><path d="M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 16"/></svg>
      <span class="pd-tooltip">${D(`toolbar.drag`)}<span class="pd-shortcut">${M}D</span></span>
    </button>
    <button id="pd-tb-comment">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
      <span class="pd-tooltip">${D(`toolbar.comment`)}<span class="pd-shortcut">${M}C</span></span>
    </button>
  `,document.body.appendChild(O),O.querySelector(`#pd-tb-select`).addEventListener(`click`,()=>N(`select`)),O.querySelector(`#pd-tb-drag`).addEventListener(`click`,()=>N(`drag`)),O.querySelector(`#pd-tb-comment`).addEventListener(`click`,()=>N(`comment`)),P())}function N(e){j||(A=A===e?null:e,P(),Je?.onModeChange(A))}function P(){O&&(O.querySelector(`#pd-tb-select`).classList.toggle(`pd-active`,A===`select`),O.querySelector(`#pd-tb-drag`).classList.toggle(`pd-active`,A===`drag`),O.querySelector(`#pd-tb-comment`).classList.toggle(`pd-active`,A===`comment`),O.classList.toggle(`pd-disabled`,j))}function Xe(){O?.remove(),k?.remove(),O=null,k=null,A=null,j=!1}function Ze(e){A=e,P()}function Qe(e){j=e,P()}function $e(){return j}function et(e){return!!e.closest(`#prism-studio-toolbar`)}function F(e){N(e)}var I=null,L=null,tt=null,R=null,z=null;function nt(){L||(L=document.createElement(`style`),L.id=`prism-studio-comment-style`,L.textContent=`
    #prism-studio-comment-popup {
      position: absolute;
      z-index: 2147483647;
      background: #fff;
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      padding: 12px;
      width: 240px;
      box-shadow: 0 8px 30px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.06);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      display: none;
    }
    #prism-studio-comment-popup textarea {
      width: 100%;
      min-height: 60px;
      border: 1px solid #e5e7eb;
      border-radius: 6px;
      padding: 8px;
      font-size: 12px;
      font-family: inherit;
      resize: vertical;
      outline: none;
      transition: border-color 0.15s;
      box-sizing: border-box;
    }
    #prism-studio-comment-popup textarea:focus {
      border-color: #6366f1;
    }
    #prism-studio-comment-popup .pd-comment-actions {
      display: flex;
      justify-content: flex-end;
      gap: 6px;
      margin-top: 8px;
    }
    #prism-studio-comment-popup button {
      padding: 4px 12px;
      border-radius: 6px;
      font-size: 12px;
      cursor: pointer;
      border: 1px solid #e5e7eb;
      background: #fff;
      color: #374151;
      transition: all 0.15s;
      font-family: inherit;
    }
    #prism-studio-comment-popup button:hover {
      background: #f3f4f6;
    }
    #prism-studio-comment-popup .pd-comment-confirm {
      background: #6366f1;
      color: #fff;
      border-color: #6366f1;
    }
    #prism-studio-comment-popup .pd-comment-confirm:hover {
      background: #4f46e5;
    }
    #prism-studio-comment-popup .pd-comment-confirm:disabled {
      opacity: 0.5;
      cursor: default;
    }
  `,document.head.appendChild(L))}function rt(e,t,n){B(),tt=t,R=n||null,I=document.createElement(`div`),I.id=`prism-studio-comment-popup`,I.innerHTML=`
    <textarea placeholder="${D(`comment.placeholder`)}" autofocus></textarea>
    <div class="pd-comment-actions">
      <button class="pd-comment-cancel">${D(`comment.cancel`)}</button>
      <button class="pd-comment-confirm" disabled>${D(`comment.confirm`)}</button>
    </div>
  `,document.body.appendChild(I);let r=I.querySelector(`textarea`),i=I.querySelector(`.pd-comment-confirm`),a=I.querySelector(`.pd-comment-cancel`);r.addEventListener(`input`,()=>{i.disabled=!r.value.trim()}),r.addEventListener(`keydown`,e=>{e.key===`Escape`&&(e.preventDefault(),e.stopPropagation(),R?.(),B())}),i.addEventListener(`click`,()=>{let e=r.value.trim();e&&(tt?.(e),B())}),a.addEventListener(`click`,()=>{R?.(),B()}),z=e=>{I?.contains(e.target)||(R?.(),B())},setTimeout(()=>{z&&document.addEventListener(`pointerdown`,z,!0)},0);let o=e.getBoundingClientRect(),s=o.right+8,c=o.top+window.scrollY;s+260>window.innerWidth&&(s=o.left-260,s<0&&(s=8)),c+150>window.innerHeight+window.scrollY&&(c=window.innerHeight+window.scrollY-160),I.style.display=`block`,I.style.left=s+`px`,I.style.top=c+`px`,requestAnimationFrame(()=>r.focus())}function B(){z&&document.removeEventListener(`pointerdown`,z,!0),z=null,I?.remove(),I=null,tt=null,R=null}function it(){B(),L?.remove(),L=null}function at(e){return!!e.closest(`#prism-studio-comment-popup`)}var V=!1,ot=[];function st(){return V}function ct(e){ot.push(e)}function H(e){if(!V)try{chrome.runtime.sendMessage(e).catch(ut)}catch{ut()}}function lt(){if(!V){V=!0,console.warn(`[Prism Studio] Extension context invalidated — cleaning up`);for(let e of ot)try{e()}catch(e){console.error(`[Prism Studio] cleanup error:`,e)}}}function ut(){V||chrome.runtime?.id||lt()}function dt(){try{return!!chrome.runtime?.id}catch{return!1}}function ft(){if(!V)try{chrome.runtime.connect({name:`prism-content-keepalive`}).onDisconnect.addListener(()=>{setTimeout(()=>{dt()?ft():lt()},500)})}catch{lt()}}document.readyState===`complete`?ft():window.addEventListener(`load`,()=>ft(),{once:!0});var U=!1,W=!1,G=!1,K=null,pt=`prism-studio-comment-cursor`;function mt(){let e=`url(data:image/svg+xml;base64,${btoa(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#6366f1" stroke="white" stroke-width="1.5"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`)}) 4 4, pointer`,t=document.getElementById(pt);t||(t=document.createElement(`style`),t.id=pt,document.head.appendChild(t)),t.textContent=`*, *::before, *::after { cursor: ${e} !important; } #prism-studio-comment-popup *, #prism-studio-comment-popup textarea { cursor: auto !important; }`}function ht(){document.getElementById(pt)?.remove()}function gt(e){U=!1,G=!1,document.removeEventListener(`pointermove`,q,!0),document.removeEventListener(`click`,J,!0),document.removeEventListener(`pointerdown`,St,!0),document.removeEventListener(`pointerleave`,Y,!0),document.removeEventListener(`touchmove`,q,!0),document.removeEventListener(`touchend`,J,!0),g(),ht(),Ue(),document.body.style.cursor=``,H({type:`COMMENT_TARGET_SELECTED`,payload:e})}function _t(){v(),he(),Se(),K=null,H({type:`ELEMENT_DESELECTED`})}function vt(e){_t(),H({type:`COMMENT_CANCELLED`,payload:{domPath:e}})}function yt(){Z(),Ze(null),H({type:`OPEN_CHAT`})}ct(()=>{Z(),it(),Tt()});function bt(e){if(et(e)||at(e))return!0;let t=e;for(;t;){if(t.id?.startsWith(`prism-studio-`))return!0;t=t.parentElement}return!1}function xt(e){return`touches`in e&&e.touches.length>0?document.elementFromPoint(e.touches[0].clientX,e.touches[0].clientY):`clientX`in e?document.elementFromPoint(e.clientX,e.clientY):e.target}function q(e){if(!U)return;let t=xt(e);t&&(bt(t)||t!==Ae()&&me(t,l(t).component?.name))}function J(e){if(!U)return;let t=xt(e);if(t&&!bt(t)&&t.contentEditable!==`true`){if(e.preventDefault(),e.stopPropagation(),G){K=t,g(),_(t);let e=l(t);H({type:`ELEMENT_SELECTED`,payload:e}),rt(t,t=>{_t(),H({type:`COMMENT_ADDED`,payload:{element:e,comment:t}})},()=>vt(e.domPath)),gt(e);return}K=t,g(),_(t),Ce(t),H({type:`ELEMENT_SELECTED`,payload:l(t)})}}function St(e){if(!U||!W)return;let t=e.target;bt(t)||t.contentEditable!==`true`&&De(e,t)}function Y(){g()}function X(){if(!U){U=!0;try{pe(),xe(),nt(),be((e,t,n)=>{H({type:`DRAG_MOVE`,payload:{element:l(e),from:t,to:n}})})}catch(e){console.error(`[Prism Studio] Init error:`,e)}document.addEventListener(`pointermove`,q,!0),document.addEventListener(`click`,J,!0),document.addEventListener(`pointerdown`,St,!0),document.addEventListener(`pointerleave`,Y,!0),document.addEventListener(`touchmove`,q,!0),document.addEventListener(`touchend`,J,!0),He({plain:{escape:()=>yt()},ctrlShift:{e:()=>F(`select`),d:()=>F(`drag`),c:()=>F(`comment`)}}),W&&document.body.classList.add(`prism-studio-drag-mode`),W||(document.body.style.cursor=`default`),console.log(`[Prism Studio] Design mode enabled`)}}function Z(){U&&(U=!1,W=!1,G=!1,document.removeEventListener(`pointermove`,q,!0),document.removeEventListener(`click`,J,!0),document.removeEventListener(`pointerdown`,St,!0),document.removeEventListener(`pointerleave`,Y,!0),document.removeEventListener(`touchmove`,q,!0),document.removeEventListener(`touchend`,J,!0),g(),v(),B(),he(),Se(),Ue(),document.body.classList.remove(`prism-studio-drag-mode`),document.body.style.cursor=``,ht(),K=null,H({type:`ELEMENT_DESELECTED`}),console.log(`[Prism Studio] Design mode disabled`))}function Q(e){try{let t=e.split(` > `),n=document.body;for(let e of t){let t=e.match(/\[(\d+)\]$/);if(t){let e=parseInt(t[1]),r=Array.from(n.children);if(e<0||e>=r.length)return null;n=r[e]}else if(e.includes(`#`)){let[,t]=e.split(`#`),r=Array.from(n.children).find(e=>e.id===t);if(!r)return null;n=r}else{let t=Array.from(n.children).find(t=>{let n=t.tagName.toLowerCase();if(e.includes(`.`)){let[r,...i]=e.split(`.`);return n===r&&i.every(e=>t.classList.contains(e))}return n===e});if(!t)return null;n=t}}return n}catch{return null}}var Ct=new Set([`DESIGN_MODE_ON`,`DESIGN_MODE_OFF`,`START_COMMENT_MODE`,`STOP_COMMENT_MODE`,`ENABLE_DRAG_MODE`,`DISABLE_DRAG_MODE`,`GET_DOM_TREE`,`GET_PENDING_CHANGES`,`CLEAR_CHANGES`,`HIGHLIGHT_ELEMENT`,`UNHIGHLIGHT_ELEMENT`,`SELECT_ELEMENT`,`APPLY_STYLE_PREVIEW`,`CLEAR_STYLE_PREVIEW`,`SHOW_TOOLBAR`,`HIDE_TOOLBAR`,`TOOLBAR_DISABLE`,`RELOAD_IF_STATIC`,`PING`]);chrome.runtime.onMessage.addListener((e,t,n)=>{if(st()||!Ct.has(e.type))return!1;switch(e.type){case`DESIGN_MODE_ON`:X(),n({success:!0});break;case`DESIGN_MODE_OFF`:Z(),Ze(null),n({success:!0});break;case`START_COMMENT_MODE`:Z(),G=!0,X(),mt(),n({success:!0});break;case`STOP_COMMENT_MODE`:Z(),n({success:!0});break;case`ENABLE_DRAG_MODE`:W=!0,document.body.classList.add(`prism-studio-drag-mode`),n({success:!0});break;case`DISABLE_DRAG_MODE`:W=!1,document.body.classList.remove(`prism-studio-drag-mode`),n({success:!0});break;case`GET_DOM_TREE`:{Be();let e=ze(document.body);n(e),H({type:`DOM_TREE`,payload:e});break}case`GET_PENDING_CHANGES`:n({changes:je(),moves:Me(),component:K?l(K).component:null});break;case`CLEAR_CHANGES`:Ne(),n({success:!0});break;case`HIGHLIGHT_ELEMENT`:{let t=Q(e.payload.domPath);t&&me(t),n({success:!!t});break}case`UNHIGHLIGHT_ELEMENT`:g(),n({success:!0});break;case`SELECT_ELEMENT`:{let t=Q(e.payload.domPath);if(t){if(G){K=t,g(),_(t);let e=l(t);H({type:`ELEMENT_SELECTED`,payload:e}),rt(t,t=>{_t(),H({type:`COMMENT_ADDED`,payload:{element:e,comment:t}})},()=>vt(e.domPath)),gt(e),t.scrollIntoView({behavior:`smooth`,block:`center`}),n({success:!0});break}K=t,g(),_(t),Ce(t),t.scrollIntoView({behavior:`smooth`,block:`center`}),H({type:`ELEMENT_SELECTED`,payload:l(t)})}n({success:!!t});break}case`APPLY_STYLE_PREVIEW`:{let t=K||Q(e.payload.domPath);if(t){let n=e.payload.property,r=n.replace(/-([a-z])/g,(e,t)=>t.toUpperCase()),i=window.getComputedStyle(t).getPropertyValue(n);t.style[r]=e.payload.value,ke(t,n,i,e.payload.value)}n({success:!!t});break}case`CLEAR_STYLE_PREVIEW`:{let t=Q(e.payload.domPath);t&&t.removeAttribute(`style`),n({success:!!t});break}case`SHOW_TOOLBAR`:wt(),n({success:!0});break;case`HIDE_TOOLBAR`:Z(),Tt(),n({success:!0});break;case`TOOLBAR_DISABLE`:Qe(e.payload.disabled),e.payload.disabled&&(Z(),Ze(null)),n({success:!0});break;case`RELOAD_IF_STATIC`:location.protocol===`file:`&&location.reload(),n({success:!0});break;case`PING`:n({active:U});break}return!0}),document.addEventListener(`keydown`,e=>{if(!(e.ctrlKey||e.metaKey)||!e.shiftKey||$e())return;let t=e.key.toLowerCase();(t===`e`||t===`d`||t===`c`)&&(e.preventDefault(),F(t===`e`?`select`:t===`d`?`drag`:`comment`))},!0);var $=!1;function wt(){$||($=!0,Ye({onModeChange(e){Z(),W=!1,G=!1,e===`select`?(X(),H({type:`OPEN_NAVIGATOR`,payload:{mode:`select`}})):e===`drag`?(W=!0,X(),H({type:`OPEN_NAVIGATOR`,payload:{mode:`drag`}})):e===`comment`?(G=!0,X(),H({type:`OPEN_CHAT`})):H({type:`OPEN_CHAT`})}}))}function Tt(){Xe(),$=!1}setTimeout(()=>H({type:`CONTENT_READY`}),100),console.log(`[Prism Studio] Content script loaded`);